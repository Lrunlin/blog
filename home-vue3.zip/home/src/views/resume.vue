<template>
等5月左右可能有校招会，虽然现在才大二，但是可以出去看看，到时候在更新具体简历
<div>Vue3+jQuery，node会点，mysql会一点点语句，scss会点</div>
<div>做过一些毕设和，公司小项目别的用用npm包echarts之类的</div>
</template>
<script setup>
import {ref} from 'vue'





</script>
<style scoped lang='scss'>



</style>