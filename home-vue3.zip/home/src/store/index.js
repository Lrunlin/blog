import { createStore } from 'vuex'

export default createStore({
  state: {
    articleUrl: 'https://blog.blogweb.cn/',
    name:'刘润霖'
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
